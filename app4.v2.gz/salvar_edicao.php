<?php
require 'vendor/autoload.php';

use Aws\DynamoDb\DynamoDbClient;
use Aws\S3\S3Client;
use Aws\Exception\AwsException;

$region = 'us-west-2';

// Configurações dos clientes AWS
$dynamoDbClient = new DynamoDbClient([
    'region' => $region,
    'version' => 'latest',
]);

$s3Client = new S3Client([
    'region' => $region,
    'version' => 'latest',
]);

// Função para validar os dados do cliente (reutilize a função de salvar_cliente.php)
function validarDados($dados) {
    $erros = [];
    if (empty($dados['nome'])) {
        $erros[] = "Nome é obrigatório.";
    }
    if (empty($dados['email']) || !filter_var($dados['email'], FILTER_VALIDATE_EMAIL)) {
        $erros[] = "Email inválido.";
    }
    return $erros;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Salvando Edição</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <?php include 'menu.php'; ?>
        <div class="content">
            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $cpf = $_POST['cpf']; // CPF (Chave Primária)
                $nome = $_POST['nome'];
                $email = $_POST['email'];
                $telefone = $_POST['telefone'];
                $foto = $_FILES['foto']; // Arquivo da foto
                $generalPreferences = $_POST['general_preferences'];

                $dadosCliente = [
                    'nome' => $nome,
                    'email' => $email,
                    'telefone' => $telefone,
                    'general_preferences' => $generalPreferences
                ];

                $erros = validarDados($dadosCliente); // Use a função de validação

                if (!empty($erros)) {
                    echo "<h2>Erros no formulário:</h2>";
                    foreach ($erros as $erro) {
                        echo "<p class='error'>" . htmlspecialchars($erro) . "</p>";
                    }
                    echo "<p><a href='editar.php?cpf=" . urlencode($cpf) . "'>Voltar para editar</a></p>"; // Voltar para editar
                } else {

                    $fotoUrl = null;
                    // Lógica para upload da foto (se uma nova foto foi enviada)
                    if ($foto['error'] === UPLOAD_ERR_OK && !empty($foto['tmp_name'])) {
                        // 1. Remove a foto antiga do S3 (se houver) - IMPORTANTE!
                        //    (Implemente a lógica para remover a foto antiga aqui)

                        // 2. Faz o upload da nova foto para o S3
                        $key = 'fotos/' . uniqid() . '-' . $foto['name'];
                        try {
                            $result = $s3Client->putObject([
                                'Bucket' => 'new-bkt2027',
                                'Key' => $key,
                                'Body' => fopen($foto['tmp_name'], 'rb'),
                            ]);
                            $fotoUrl = $result['ObjectURL'];
                            echo "<p>Nova foto enviada para o S3: " . htmlspecialchars($fotoUrl) . "</p>";
                        } catch (AwsException $e) {
                            echo "<p class='error'>Erro ao enviar a nova foto para o S3: " . htmlspecialchars($e->getMessage()) . "</p>";
                            $fotoUrl = null; // Define como nulo em caso de erro
                        }
                    } else {
                        // Se nenhuma nova foto foi enviada, mantenha a fotoUrl existente
                        // (Implemente a lógica para obter a fotoUrl antiga aqui)
                    }

                    // Atualiza os dados no DynamoDB
                    try {
                        $updateResult = $dynamoDbClient->updateItem([
                            'TableName' => 'Clientes',
                            'Key' => [
                                'cpf' => ['S' => $cpf],
                            ],
                            'UpdateExpression' => 'SET #nome = :nome, email = :email, telefone = :telefone, fotoUrl = :fotoUrl, general_preferences = :general_preferences',
                            'ExpressionAttributeNames' => [
                                '#nome' => 'nome', // Usa #nome para evitar conflitos
                            ],
                            'ExpressionAttributeValues' => [
                                ':nome' => ['S' => $nome],
                                ':email' => ['S' => $email],
                                ':telefone' => ['S' => $telefone],
                                ':fotoUrl' => ['S' => $fotoUrl ? $fotoUrl : ''], // Usa a nova URL ou a antiga
                                ':general_preferences' => ['S' => $generalPreferences ? $generalPreferences : ''],
                            ],
                            'ReturnValues' => 'ALL_NEW', // Retorna os dados atualizados (opcional)
                        ]);

                        echo "<h2>Dados do cliente atualizados com sucesso!</h2>";

                        // Redireciona para a página de detalhes (ou para a listagem)
                        echo "<p><a href='detalhe.php?cpf=" . urlencode($cpf) . "'>Ver detalhes</a></p>";
                        echo "<p><a href='index.php'>Voltar para a listagem</a></p>";

                    } catch (AwsException $e) {
                        echo "<p class='error'>Erro ao atualizar o cliente no DynamoDB: " . htmlspecialchars($e->getMessage()) . "</p>";
                        echo "<p><a href='editar.php?cpf=" . urlencode($cpf) . "'>Voltar para editar</a></p>"; // Voltar para editar em caso de erro
                    }
                }
            } else {
                echo "<p class='error'>Método de requisição inválido.</p>";
            }
            ?>
        </div>
    </div>
</body>
</html>
