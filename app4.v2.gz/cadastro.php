<!DOCTYPE html>
<html>

<head>
    <title>Cadastro de Cliente</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">

        <nav>
            <?php include 'menu.php'; ?>
        </nav>
        <div class="content">
            <h1>Cadastro de Novo Cliente</h1>
            <form action="salvar_cliente.php" method="post" enctype="multipart/form-data">
                <div>
                    <label for="nome">Nome:</label>
                    <input type="text" id="nome" name="nome" required>
                </div>
                <br>
                <div>
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <br>
                <div>
                    <label for="telefone">Telefone:</label>
                    <input type="text" id="telefone" name="telefone" pattern="[0-9]{10,11}"
                        title="Formato: DDD + Número (apenas números)">
                </div>
                <br>
                <div>
                    <label for="cpf">CPF:</label>
                    <input type="text" id="cpf" name="cpf" required pattern="[0-9]{11}" title="Formato: 11 dígitos (apenas números)">
                </div>
                <br>
                <div>
                    <label for="foto">Foto:</label>
                    <input type="file" id="foto" name="foto">
                </div>
                <br>
                <div>
                    <label for="general_preferences">Preferências (Comidas, Hotéis, Viagens,
                        etc.):</label>
                    <textarea id="general_preferences" name="general_preferences" rows="4" cols="50"></textarea>
                </div>
                <br>
                <button type="submit">Salvar Cliente</button>
            </form>
            <br>
            <a href="index.php">Voltar para a listagem de clientes</a>
        </div>
    </div>
</body>

</html>
