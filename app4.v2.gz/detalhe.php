<!DOCTYPE html>
<html>

<head>
    <title>Detalhes do Cliente</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
        <?php include 'menu.php'; ?>
        <div class="content">
            <h1>Detalhes do Cliente</h1>
            <?php
            require 'vendor/autoload.php';

            use Aws\DynamoDb\DynamoDbClient;
            use Aws\Exception\AwsException;

            $region = 'us-west-2';

            $dynamoDbClient = new DynamoDbClient([
                'region' => $region,
                'version' => 'latest',
            ]);

            $cpf = $_GET['cpf'] ?? null;

            if ($cpf) {
                try {
                    $result = $dynamoDbClient->getItem([
                        'TableName' => 'Clientes',
                        'Key' => [
                            'cpf' => ['S' => $cpf],
                        ],
                    ]);

                    if (isset($result['Item'])) {
                        $cliente = $result['Item'];
                        $nome = $cliente['nome']['S'] ?? '';
                        $email = $cliente['email']['S'] ?? '';
                        $telefone = $cliente['telefone']['S'] ?? '';
                        $fotoUrl = $cliente['fotoUrl']['S'] ?? '';
                        $generalPreferences = $cliente['general_preferences']['S'] ?? '';

                        echo "<p><strong>Nome:</strong> " . htmlspecialchars($nome) . "</p>";
                        echo "<p><strong>Email:</strong> " . htmlspecialchars($email) . "</p>";
                        echo "<p><strong>Telefone:</strong> " . htmlspecialchars($telefone) . "</p>";
                        echo "<p><strong>CPF:</strong> " . htmlspecialchars($cpf) . "</p>";
                        if ($fotoUrl) {
                            echo "<p><strong>Foto:</strong> <img src='" . htmlspecialchars($fotoUrl) . "' alt='Foto do Cliente' style='max-width: 200px;'></p>";
                        } else {
                            echo "<p><strong>Foto:</strong> Nenhuma foto cadastrada.</p>";
                        }
                        echo "<p><strong>Preferências:</strong><br>" . nl2br(htmlspecialchars($generalPreferences)) . "</p>";
                    } else {
                        echo "<p>Cliente não encontrado.</p>";
                    }
                } catch (AwsException $e) {
                    echo "Erro ao buscar detalhes do cliente: " . htmlspecialchars($e->getMessage()) . "<br>";
                }
            } else {
                echo "<p>CPF do cliente não fornecido.</p>";
            }
            ?>
            <p><a href="index.php">Voltar para a listagem</a></p>
        </div>
    </div>
</body>

</html>
