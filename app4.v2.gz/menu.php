<nav class="menu">
    <ul>
        <li><a href="index.php">Listagem</a></li>
        <li><a href="cadastro.php">Cadastrar</a></li>
        <li><a href="exportar.php">Exportar</a></li>
        <li><a href="editar.php">Editar</a></li>
        <li><a href="excluir.php">Excluir</a></li>
    </ul>
</nav>
