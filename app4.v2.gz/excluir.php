<?php
require 'vendor/autoload.php';

use Aws\DynamoDb\DynamoDbClient;
use Aws\S3\S3Client;
use Aws\Exception\AwsException;

$region = 'us-west-2';

$s3Client = new S3Client([
    'region' => $region,
    'version' => 'latest',
]);
$dynamoDbClient = new DynamoDbClient([
    'region' => $region,
    'version' => 'latest',
]);

$exclusao_mensagem = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cpf_excluir = $_POST['cpf_excluir'] ?? null;

    if (!empty($cpf_excluir)) {
        try {
            // Obtém a URL da foto antes de excluir o cliente
            $result = $dynamoDbClient->getItem([
                'TableName' => 'Clientes',
                'Key' => [
                    'cpf' => ['S' => $cpf_excluir],
                ],
                'ProjectionExpression' => 'fotoUrl'
            ]);
            $fotoUrl = $result['Item']['fotoUrl']['S'] ?? null;

            // Exclui o cliente do DynamoDB
            $dynamoDbClient->deleteItem([
                'TableName' => 'Clientes',
                'Key' => [
                    'cpf' => ['S' => $cpf_excluir],
                ],
            ]);

            // Remove a foto do S3 (se existir)
            if ($fotoUrl) {
                $pathParts = parse_url($fotoUrl);
                $s3Key = ltrim($pathParts['path'], '/');
                try {
                    $s3Client->deleteObject([
                        'Bucket' => 'new-bkt2027',
                        'Key' => $s3Key,
                    ]);
                    $exclusao_mensagem = "<p class='success'>Cliente com CPF " . htmlspecialchars($cpf_excluir) . " excluído com sucesso e foto removida do S3.</p>";
                } catch (AwsException $e) {
                    $exclusao_mensagem = "<p class='success'>Cliente com CPF " . htmlspecialchars($cpf_excluir) . " excluído com sucesso, mas erro ao remover foto do S3: " . htmlspecialchars($e->getMessage()) . "</p>";
                }
            } else {
                $exclusao_mensagem = "<p class='success'>Cliente com CPF " . htmlspecialchars($cpf_excluir) . " excluído com sucesso.</p>";
            }
        } catch (AwsException $e) {
            $exclusao_mensagem = "<p class='error'>Erro ao excluir cliente com CPF " . htmlspecialchars($cpf_excluir) . ": " . htmlspecialchars($e->getMessage()) . "</p>";
        }
    } else {
        $exclusao_mensagem = "<p class='warning'>Por favor, insira o CPF para exclusão.</p>";
    }
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Excluir Cliente</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .success {
            color: green;
        }

        .error {
            color: red;
        }

        .warning {
            color: orange;
        }
    </style>
</head>

<body>
    <div class="container">
        <?php include 'menu.php'; ?>
        <div class="content">
            <h1>Excluir Cliente</h1>
            <hr>
            <?php echo $exclusao_mensagem; ?>
            <form method="post">
                <div>
                    <label for="cpf_excluir">CPF do Cliente:</label>
                    <input type="text" id="cpf_excluir" name="cpf_excluir" placeholder="Digite o CPF" required>
                </div>
                <br>
                <button type="submit">Excluir Cliente</button>
            </form>
            <br>
            <p><a href="index.php">Voltar para a listagem de clientes</a></p>
        </div>
    </div>
</body>

</html>
