<?php
require 'vendor/autoload.php';

use Aws\S3\S3Client;
use Aws\DynamoDb\DynamoDbClient;
use Aws\Exception\AwsException;

$region = 'us-west-2'; // Mantenha a região

$s3Client = new S3Client([
    'region' => $region,
    'version' => 'latest',
]);

$dynamoDbClient = new DynamoDbClient([
    'region' => $region,
    'version' => 'latest',
]);

// Função para validar os dados do cliente
function validarDados($dados) {
    $erros = [];
    if (empty($dados['nome'])) {
        $erros[] = "Nome é obrigatório.";
    }
    if (empty($dados['email']) || !filter_var($dados['email'], FILTER_VALIDATE_EMAIL)) {
        $erros[] = "Email inválido.";
    }
    if (empty($dados['cpf'])) {
        $erros[] = "CPF é obrigatório.";
    }
    return $erros;
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Salvando Cliente</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <?php include 'menu.php'; ?>
    <div class="content">
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $dadosCliente = [
                'nome' => $_POST['nome'],
                'email' => $_POST['email'],
                'telefone' => $_POST['telefone'],
                'cpf' => $_POST['cpf'],
                'general_preferences' => $_POST['general_preferences']
            ];
            $foto = $_FILES['foto'];

            $erros = validarDados($dadosCliente);
            if (!empty($erros)) {
                echo "<h2>Erros no formulário:</h2>";
                foreach ($erros as $erro) {
                    echo "<p>" . htmlspecialchars($erro) . "</p>";
                }
            } else {

                $fotoUrl = null;
                if ($foto['error'] === UPLOAD_ERR_OK && !empty($foto['tmp_name'])) {
                    $key = 'fotos/' . uniqid() . '-' . $foto['name'];
                    try {
                        $result = $s3Client->putObject([
                            'Bucket' => 'new-bkt2027',
                            'Key' => $key,
                            'Body' => fopen($foto['tmp_name'], 'rb'),
                        ]);
                        $fotoUrl = $result['ObjectURL'];
                        echo "<p>Foto enviada para o S3: " . htmlspecialchars($fotoUrl) . "</p>";
                    } catch (AwsException $e) {
                        echo "<p>Erro ao enviar a foto para o S3: " . htmlspecialchars($e->getMessage()) . "</p>";
                    }
                } else {
                    echo "<p>Nenhuma foto enviada ou erro no upload.</p>";
                    $fotoUrl = '';
                }

                try {
                    $dynamoDbClient->putItem([
                        'TableName' => 'Clientes',
                        'Item' => [
                            'cpf' => ['S' => $dadosCliente['cpf']],
                            'nome' => ['S' => $dadosCliente['nome']],
                            'email' => ['S' => $dadosCliente['email']],
                            'telefone' => ['S' => $dadosCliente['telefone']],
                            'fotoUrl' => ['S' => $fotoUrl ? $fotoUrl : ''],
                            'general_preferences' => ['S' => $dadosCliente['general_preferences'] ? $dadosCliente['general_preferences'] : '']
                        ]
                    ]);
                    echo "<h2>Cliente cadastrado com sucesso!</h2>";
                    echo '<p><a href="index.php">Voltar para a listagem</a></p>';
                } catch (AwsException $e) {
                    echo "<h2>Erro ao salvar o cliente no DynamoDB:</h2>";
                    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
                }
            }
        } else {
            echo "<p>Método de requisição inválido.</p>";
        }
        ?>
    </div>
</div>
</body>
</html>
