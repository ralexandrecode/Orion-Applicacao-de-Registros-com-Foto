<!DOCTYPE html>
<html>

<head>
    <title>Listagem de Clientes</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
        <?php include 'menu.php'; ?>
        <div class="content">
            <h1>Lista de Clientes</h1>
            <hr>
            <?php
            require 'vendor/autoload.php';

            use Aws\DynamoDb\DynamoDbClient;
            use Aws\Exception\AwsException;

            $region = 'us-west-2';

            $dynamoDbClient = new DynamoDbClient([
                'region' => $region,
                'version' => 'latest',
            ]);

            try {
                $result = $dynamoDbClient->scan([
                    'TableName' => 'Clientes',
                ]);

                if (count($result['Items']) > 0) {
                    echo "<table>";
                    echo "<thead><tr><th>Nome</th><th>Email</th><th>CPF</th><th>Preferências</th><th>Ações</th></tr></thead>";
                    echo "<tbody>";
                    foreach ($result['Items'] as $item) {
                        $nome = $item['nome']['S'] ?? '';
                        $email = $item['email']['S'] ?? '';
                        $cpf = $item['cpf']['S'] ?? '';
                        $generalPreferences = $item['general_preferences']['S'] ?? '';
                        $shortPreferences = substr(htmlspecialchars($generalPreferences), 0, 50) . (strlen($generalPreferences) > 50 ? '...' : '');
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($nome) . "</td>";
                        echo "<td>" . htmlspecialchars($email) . "</td>";
                        echo "<td>" . htmlspecialchars($cpf) . "</td>";
                        echo "<td>" . $shortPreferences . "</td>";
                        echo "<td><a href='detalhe.php?cpf=" . urlencode($cpf) . "'>Detalhes</a></a></td>";
                        echo "</tr>";
                    }
                    echo "</tbody>";
                    echo "</table>";
                } else {
                    echo "<p>Nenhum cliente cadastrado.</p>";
                }
            } catch (AwsException $e) {
                echo "Erro ao listar clientes: " . htmlspecialchars($e->getMessage()) . "<br>";
            }
            ?>
        </div>
    </div>
</body>

</html>
