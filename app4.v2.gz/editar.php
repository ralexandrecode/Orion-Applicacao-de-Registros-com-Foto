<?php
require 'vendor/autoload.php';

use Aws\DynamoDb\DynamoDbClient;
use Aws\Exception\AwsException;

$region = 'us-west-2';

$dynamoDbClient = new DynamoDbClient([
    'region' => $region,
    'version' => 'latest',
]);

// Lógica para processar o formulário (se o CPF foi enviado)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cpf_editar'])) {
    $cpf = $_POST['cpf_editar'];

    if (!empty($cpf)) {
        try {
            $result = $dynamoDbClient->getItem([
                'TableName' => 'Clientes',
                'Key' => [
                    'cpf' => ['S' => $cpf],
                ],
            ]);

            if (isset($result['Item'])) {
                $cliente = $result['Item'];
                $nome = $cliente['nome']['S'] ?? '';
                $email = $cliente['email']['S'] ?? '';
                $telefone = $cliente['telefone']['S'] ?? '';
                $fotoUrl = $cliente['fotoUrl']['S'] ?? '';
                $generalPreferences = $cliente['general_preferences']['S'] ?? '';

                // Exibir o formulário de edição com os dados do cliente
                ?>
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Editar Cliente</title>
                    <link rel="stylesheet" href="style.css">
                </head>
                <body>
                    <div class="container">
                        <?php include 'menu.php'; ?>
                        <div class="content">
                            <h1>Editar Cliente</h1>
                            <form action="salvar_edicao.php" method="post" enctype="multipart/form-data">
                                <input type="hidden" name="cpf" value="<?php echo htmlspecialchars($cpf); ?>">
                                <div>
                                    <label for="nome">Nome:</label>
                                    <input type="text" id="nome" name="nome" value="<?php echo htmlspecialchars($nome); ?>" required>
                                </div>
                                <br>
                                <div>
                                    <label for="email">Email:</label>
                                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                                </div>
                                <br>
                                <div>
                                    <label for="telefone">Telefone:</label>
                                    <input type="text" id="telefone" name="telefone" value="<?php echo htmlspecialchars($telefone); ?>" pattern="[0-9]{10,11}"
                                        title="Formato: DDD + Número (apenas números)">
                                </div>
                                <br>
                                <div>
                                    <label for="foto">Foto:</label>
                                    <input type="file" id="foto" name="foto">
                                    <?php if ($fotoUrl): ?>
                                        <p>Foto atual: <img src="<?php echo htmlspecialchars($fotoUrl); ?>" alt="Foto do Cliente" style="max-width: 100px;"></p>
                                    <?php endif; ?>
                                </div>
                                <br>
                                <div>
                                    <label for="general_preferences">Preferências (Comidas, Hotéis, Viagens,
                                        etc.):</label>
                                    <textarea id="general_preferences" name="general_preferences" rows="4" cols="50"><?php echo htmlspecialchars($generalPreferences); ?></textarea>
                                </div>
                                <br>
                                <button type="submit">Salvar Alterações</button>
                            </form>
                            <br>
                            <a href="index.php">Voltar para a listagem</a>
                        </div>
                    </div>
                </body>
                </html>
                <?php
                exit; // Interrompe a execução após exibir o formulário
            } else {
                $mensagem = "<p class='warning'>Cliente com CPF " . htmlspecialchars($cpf) . " não encontrado.</p>";
            }

        } catch (AwsException $e) {
            $mensagem = "<p class='error'>Erro ao buscar os dados do cliente: " . htmlspecialchars($e->getMessage()) . "</p>";
        }
    } else {
        $mensagem = "<p class='warning'>Por favor, insira o CPF do cliente.</p>";
    }
}

// Se o CPF não foi fornecido ou se houve um erro, exibe o formulário para inserir o CPF
?>
<!DOCTYPE html>
<html>
<head>
    <title>Editar Cliente</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <?php include 'menu.php'; ?>
        <div class="content">
            <h1>Editar Cliente</h1>
            <hr>
            <?php if (isset($mensagem)) {
                echo $mensagem;
            } ?>
            <form method="post">
                <div>
                    <label for="cpf_editar">CPF do Cliente:</label>
                    <input type="text" id="cpf_editar" name="cpf_editar" placeholder="Digite o CPF" required>
                </div>
                <br>
                <button type="submit">Editar Cliente</button>
            </form>
            <br>
            <a href="index.php">Voltar para a listagem</a>
        </div>
    </div>
</body>
</html>
