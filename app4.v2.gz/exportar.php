<?php
require 'vendor/autoload.php';

use Aws\DynamoDb\DynamoDbClient;
use Aws\Exception\AwsException;

$region = 'us-west-2';

$dynamoDbClient = new DynamoDbClient([
    'region' => $region,
    'version' => 'latest',
]);

try {
    $result = $dynamoDbClient->scan([
        'TableName' => 'Clientes',
    ]);

    if ($result && isset($result['Items'])) {
        if (count($result['Items']) > 0) {
            $filename = "clientes_" . date("YmdHis") . ".csv";
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            $output = fopen('php://output', 'w');

            // Escreva o cabeçalho do CSV
            fputcsv($output, array('Nome', 'Email', 'CPF', 'Telefone', 'Foto URL', 'Preferências'));

            // Escreva os dados de cada cliente
            foreach ($result['Items'] as $item) {
                $nome = $item['nome']['S'] ?? '';
                $email = $item['email']['S'] ?? '';
                $cpf = $item['cpf']['S'] ?? '';
                $telefone = $item['telefone']['S'] ?? '';
                $fotoUrl = $item['fotoUrl']['S'] ?? '';
                $generalPreferences = $item['general_preferences']['S'] ?? '';

                fputcsv($output, array($nome, $email, $cpf, $telefone, $fotoUrl, $generalPreferences));
            }

            fclose($output);
            exit(); // Importante: interrompe a execução do script após a geração do CSV
        } else {
            echo "<p class='warning'>Nenhum cliente cadastrado para exportar.</p>";
        }
    } else {
        echo "<p class='error'>Erro ao obter dados do DynamoDB.</p>";
    }
} catch (AwsException $e) {
    echo "<p class='error'>Erro ao exportar clientes: " . htmlspecialchars($e->getMessage()) . "</p>";
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Exportar Clientes</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
        <?php include 'menu.php'; ?>
        <div class="content">
            <h1>Exportar Clientes</h1>
            <hr>
            <?php
            // Se não houver clientes ou ocorrer um erro, a mensagem será exibida aqui
            if (isset($e)) {
                echo "<p class='error'>Erro ao exportar clientes: " . htmlspecialchars($e->getMessage()) . "</p>";
            } elseif (isset($result) && count($result['Items']) == 0) {
                echo "<p class='warning'>Nenhum cliente cadastrado para exportar.</p>";
            }
            ?>
        </div>
    </div>
</body>

</html>
